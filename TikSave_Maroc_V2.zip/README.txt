# TikSave Maroc V2

## Files
- `index.html`: complete website.
- `robots.txt`: crawler instructions.
- `sitemap.xml`: sitemap for Google Search Console.

## Publish on GitHub Pages
1. Open your `dmchahidi-coder/tiksave` repository.
2. Put `index.html`, `robots.txt`, and `sitemap.xml` in the published root folder.
3. Commit the changes and wait for GitHub Pages to deploy.
4. Open `https://dmchahidi-coder.github.io/tiksave/` and test the language selector and a public TikTok URL.
5. In Google Search Console, submit `https://dmchahidi-coder.github.io/tiksave/sitemap.xml`.

## Important
- Video/audio processing uses the third-party TikWM API. Its availability, limits, CORS policy, and terms are outside this site's control.
- Direct downloading may fall back to opening the media URL in a new tab if the media host blocks browser-side downloads.
- The old unknown ad scripts and redirect-style extra link were intentionally not copied into this version. Add advertising only from a provider you trust and have reviewed.
- Use only content you have permission to download and reuse.
